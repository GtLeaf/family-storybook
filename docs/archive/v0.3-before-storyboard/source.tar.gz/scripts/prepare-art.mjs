import sharp from "sharp";
for (const name of ["cover", "forest", "tree"]) {
  await sharp(`docs/assets/${name}-source.png`)
    .resize({ width: 1440, withoutEnlargement: true })
    .webp({ quality: 84 })
    .toFile(`public/art/${name}.webp`);
}
for (const name of ["bear", "pig", "donkey"]) {
  await sharp(`docs/assets/${name}-source.png`)
    .resize({ height: 720, withoutEnlargement: true })
    .webp({ quality: 85, alphaQuality: 100 })
    .toFile(`public/art/${name}.webp`);
}
