export const STAGE_IDS = [
  "intro",
  "find",
  "wind-talk",
  "walk",
  "worry",
  "choice",
  "response",
  "companion-talk",
  "stones",
  "picnic",
  "ending",
  "diary",
] as const;
export type Stage = (typeof STAGE_IDS)[number];
export type Art = "cover" | "forest" | "tree";
export type CompanionChoice = "listen" | "stay";
export const ITEMS = ["cup", "napkin", "basket"] as const;
export type Item = (typeof ITEMS)[number];
export const FRIENDS = ["bear", "pig", "donkey"] as const;
export type Friend = (typeof FRIENDS)[number];
export const FRIEND_NAMES: Record<Friend, string> = {
  bear: "维尼",
  pig: "小猪",
  donkey: "屹耳",
};
export const ITEM_NAMES: Record<Item, string> = {
  cup: "杯子",
  napkin: "餐巾",
  basket: "篮子",
};
export type Line = { speaker: string; text: string };
export type Scene = {
  node: string;
  chapter: number;
  location: string;
  title: string;
  art: Art;
  lines: Line[];
  next: string;
  instruction?: string;
};

export const STORY: Record<Stage, Scene> = {
  intro: {
    node: "S01",
    chapter: 1,
    location: "林边小路",
    title: "咦，风也来野餐了",
    art: "forest",
    lines: [
      {
        speaker: "故事开始了",
        text: "今天，维尼和小猪准备去野餐。风也来了。它来得很快，走的时候，带走了几样没打算出门的东西。",
      },
      { speaker: "维尼", text: "我想，杯子一定没有长脚。至少，刚才还没有。" },
      { speaker: "小猪", text: "我们一起找找吧。" },
    ],
    next: "我们来找找",
  },
  find: {
    node: "S02",
    chapter: 1,
    location: "林边小路",
    title: "小东西，藏在哪里？",
    art: "forest",
    lines: [
      {
        speaker: "小猪",
        text: "杯子、餐巾，还有篮子。看看草丛和树根旁，点一点，把它们找回来吧。",
      },
    ],
    instruction: "找一找，点一点露出来的小东西",
    next: "都找到了",
  },
  "wind-talk": {
    node: "S02-A",
    chapter: 1,
    location: "一起聊一句",
    title: "你从哪里看出风来过？",
    art: "forest",
    lines: [
      {
        speaker: "留一点时间给彼此",
        text: "是倒下的小草，还是跑远的餐巾？一起看看，也可以说说你发现的别的线索。",
      },
    ],
    next: "继续找朋友",
  },
  walk: {
    node: "S03",
    chapter: 2,
    location: "通往大树的小路",
    title: "还有一个朋友的位置",
    art: "forest",
    lines: [
      { speaker: "小猪", text: "屹耳也许想和我们一起。" },
      { speaker: "维尼", text: "好主意。篮子里，还有一个朋友的位置。" },
      {
        speaker: "轻轻往前走",
        text: "他们沿着小路往前走。风小了一点，树影轻轻晃着。",
      },
    ],
    next: "去大树旁",
  },
  worry: {
    node: "S04",
    chapter: 2,
    location: "大树旁",
    title: "屹耳有一点点担心",
    art: "tree",
    lines: [
      { speaker: "小猪", text: "我们来请你一起野餐。" },
      {
        speaker: "屹耳",
        text: "谢谢。我只是想，风也许还会回来。到时候，垫子会飞，杯子会倒。",
      },
      { speaker: "维尼", text: "嗯。那我们先不着急打开篮子。" },
    ],
    next: "我们可以怎样陪他",
  },
  choice: {
    node: "S05",
    chapter: 2,
    location: "大树旁",
    title: "陪伴，可以有不同的样子",
    art: "tree",
    lines: [
      {
        speaker: "轮到你来决定",
        text: "先听他说说，或者在旁边坐一会儿。点一个选项听一听，再决定怎样陪他。",
      },
    ],
    next: "就这样陪他",
  },
  response: {
    node: "S05-R",
    chapter: 2,
    location: "大树旁",
    title: "有朋友在，就很好",
    art: "tree",
    lines: [],
    next: "留一点时间聊聊",
  },
  "companion-talk": {
    node: "S05-A",
    chapter: 2,
    location: "一起聊一句",
    title: "你想怎样被陪伴？",
    art: "tree",
    lines: [
      {
        speaker: "家长也可以先说说",
        text: "如果是你，希望有人听一听，还是陪你坐一会儿？也可以有别的办法。不知道也没关系。",
      },
    ],
    next: "一起想办法",
  },
  stones: {
    node: "S06",
    chapter: 2,
    location: "背风的大树旁",
    title: "让垫子稳稳地待着",
    art: "tree",
    lines: [
      {
        speaker: "小猪",
        text: "篮子压住了一角，这里还有三块石头。点一点翘起的垫角，让垫子稳稳地待在这里。",
      },
    ],
    instruction: "点一下垫角，放上一块小石头",
    next: "摆好我们的野餐",
  },
  picnic: {
    node: "S07",
    chapter: 3,
    location: "背风草地",
    title: "这里，给你留了个位置",
    art: "tree",
    lines: [
      {
        speaker: "一起布置吧",
        text: "给每位朋友选一个座位。你摆一份，也可以请家长摆一份。再添一朵花、一片叶子，就成了你们的小小野餐。",
      },
    ],
    instruction: "点一个座位，把餐具放在那里",
    next: "开餐吧",
  },
  ending: {
    node: "S08",
    chapter: 3,
    location: "我们的野餐",
    title: "朋友在旁边，这里挺好的",
    art: "tree",
    lines: [
      { speaker: "小猪", text: "东西找到了，垫子也没有飞走。" },
      { speaker: "屹耳", text: "风还在。不过，这里挺好的。" },
      {
        speaker: "维尼",
        text: "嗯。我喜欢东西待在该待的地方。比如，朋友在旁边。",
      },
      {
        speaker: "故事的最后",
        text: "这一天没有完全照计划发生。可他们还是坐在了一起。",
      },
    ],
    next: "把今天记下来",
  },
  diary: {
    node: "S09",
    chapter: 3,
    location: "我的冒险日记",
    title: "我们的小小野餐",
    art: "tree",
    lines: [
      {
        speaker: "一起完成的一天",
        text: "今天，我们找回了野餐用品，还一起把垫子固定好了。每位朋友，都有了自己的位置。",
      },
    ],
    next: "回到书架",
  },
};

export const RESPONSES: Record<CompanionChoice, Line[]> = {
  listen: [
    { speaker: "维尼", text: "你愿意告诉我们，最担心什么吗？" },
    { speaker: "屹耳", text: "我不想刚坐下来，就又得追着垫子跑。" },
    { speaker: "小猪", text: "那我们想想，怎么让垫子待在原地。" },
  ],
  stay: [
    {
      speaker: "安静地坐一会儿",
      text: "他们在屹耳旁边坐了一小会儿。没有谁急着说下一句话。",
    },
    { speaker: "屹耳", text: "谢谢你们等我。也许，我们可以先把垫子压住。" },
  ],
};

export const CHOICE_TEXT: Record<
  CompanionChoice,
  { title: string; description: string }
> = {
  listen: {
    title: "先听他说说",
    description: "“你愿意告诉我，最担心什么吗？”",
  },
  stay: { title: "在旁边陪一会儿", description: "“不用着急，我就在这里。”" },
};
