import { readFileSync, existsSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { audioUrl, pageAudio, type AudioClip } from "./audio";
import { STAGE_IDS } from "./story";

describe("录音交付与页面映射", () => {
  const task = readFileSync(new URL("../../TTS_TASK.md", import.meta.url), "utf8");
  const clips = [...task.matchAll(/### \w+ · (\w+)\.wav/g)].map((match) => match[1]);

  it("任务文档中的 31 段均有可打包的 MP3 和保留的 WAV 母版", () => {
    expect(clips).toHaveLength(31);
    for (const clip of clips) {
      expect(audioUrl(clip as AudioClip), clip).toMatch(/\.mp3/);
      for (const ext of ["mp3", "wav"]) {
        expect(existsSync(new URL(`../../audio/tts/v1/${clip}.${ext}`, import.meta.url)), clip)
          .toBe(true);
      }
    }
  });

  it("覆盖每页及两条分支，分支文件互不混用", () => {
    const pageClips = STAGE_IDS.flatMap((stage) => stage === "response"
      ? [pageAudio(stage, "listen"), pageAudio(stage, "stay")]
      : [pageAudio(stage, null)]);
    expect(new Set(pageClips).size).toBe(13);
    expect(pageAudio("response", "listen")).toBe("page_07a_response_listen");
    expect(pageAudio("response", "stay")).toBe("page_07b_response_stay");
    expect(new Set(pageClips)).toEqual(new Set(clips.filter((clip) => clip.startsWith("page_"))));
  });
});
