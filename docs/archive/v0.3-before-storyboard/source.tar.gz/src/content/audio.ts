import type { CompanionChoice, Stage } from "./story";

// 直接引用交付目录，由 Vite 生成适用于静态托管子目录的资源地址。
const urls = import.meta.glob<string>("../../audio/tts/v1/*.mp3", {
  eager: true,
  query: "?url",
  import: "default",
});

const pages = {
  intro: "page_01_intro",
  find: "page_02_find",
  "wind-talk": "page_03_wind_talk",
  walk: "page_04_walk",
  worry: "page_05_worry",
  choice: "page_06_choice",
  "companion-talk": "page_08_companion_talk",
  stones: "page_09_stones",
  picnic: "page_10_picnic",
  ending: "page_11_ending",
  diary: "page_12_diary",
} as const satisfies Record<Exclude<Stage, "response">, string>;

export type AudioClip =
  | (typeof pages)[keyof typeof pages]
  | "page_07a_response_listen"
  | "page_07b_response_stay"
  | `ui_find_${"cup" | "napkin" | "basket" | "hint"}`
  | `ui_choice_${CompanionChoice}`
  | "ui_stone_placed"
  | `ui_seat_${"select" | "placed"}_${"bear" | "pig" | "donkey"}`
  | `ui_decoration_${"added" | "removed"}`
  | "ui_voice_preview"
  | "optional_stones_complete"
  | "optional_offline_invitation";

export type AudioSequence = AudioClip | readonly AudioClip[];

export function pageAudio(stage: Stage, choice: CompanionChoice | null): AudioClip {
  if (stage === "response")
    return choice === "stay" ? "page_07b_response_stay" : "page_07a_response_listen";
  return pages[stage];
}

export function audioUrl(clip: AudioClip): string | undefined {
  return urls[`../../audio/tts/v1/${clip}.mp3`];
}
