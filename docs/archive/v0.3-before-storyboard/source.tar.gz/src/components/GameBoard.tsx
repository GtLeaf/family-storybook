import { useState } from "react";
import { Check, Sparkles } from "lucide-react";
import {
  FRIENDS,
  FRIEND_NAMES,
  ITEMS,
  ITEM_NAMES,
  type Friend,
} from "../content/story";
import type { Action, Progress } from "../lib/progress";
import type { AudioSequence } from "../content/audio";
import { FriendPortrait, Prop } from "./Illustrations";
import { SceneArt } from "./SceneArt";

type BoardProps = {
  progress: Progress;
  dispatch: (action: Action) => void;
  feedback: (message: string, audio: AudioSequence) => void;
};
export function FindBoard({
  progress,
  dispatch,
  feedback,
  hint,
}: BoardProps & { hint: number }) {
  return (
    <SceneArt
      art="forest"
      alt="阳光照进林间小路，草丛和树根旁藏着野餐用品"
      className="find-board"
    >
      {ITEMS.map((item, i) => {
        const found = progress.found.includes(item);
        return (
          <button
            key={item}
            className={`find-object object-${i} ${found ? "found" : ""} ${hint ? "hinted" : ""}`}
            disabled={found}
            aria-label={`找到${ITEM_NAMES[item]}`}
            onClick={() => {
              dispatch({ type: "COLLECT", item });
              feedback(
                item === "cup"
                  ? "原来杯子躲在这里。"
                  : item === "napkin"
                    ? "找到一块很会旅行的餐巾。"
                    : "找到篮子了，东西有地方放了。",
                `ui_find_${item}`,
              );
            }}
          >
            {found ? (
              <Check size={26} />
            ) : (
              <>
                <Prop item={item} />
                {hint > 1 && (
                  <span className="object-label">{ITEM_NAMES[item]}</span>
                )}
              </>
            )}
          </button>
        );
      })}
      <span className="scene-caption">
        <Sparkles size={14} /> 小发现，藏在不远的地方
      </span>
    </SceneArt>
  );
}

export function PicnicBoard({
  progress,
  dispatch,
  feedback,
  stones = false,
  readOnly = false,
}: BoardProps & { stones?: boolean; readOnly?: boolean }) {
  const [selected, setSelected] = useState<Friend | null>(null);
  const nextFriend = FRIENDS.find((friend) => !progress.seats.includes(friend));
  const allSeated = !nextFriend;
  const activeFriend = selected ?? nextFriend;
  return (
    <div className="picnic-container">
      <SceneArt
        art="tree"
        alt="背风的大树下，铺着一张奶油色格纹野餐垫"
        className={`picnic-board ${readOnly ? "readonly-board" : ""}`}
      >
        {readOnly && (
          <div className="seated-friends">
            {progress.seats.map(
              (friend, i) =>
                friend && <FriendPortrait key={i} friend={friend} />,
            )}
          </div>
        )}
        <div className={`blanket ${stones ? "stone-blanket" : ""}`}>
          <div className="blanket-seam" />
          {stones ? (
            <>
              <Prop item="basket" className="corner-basket" />
              {[0, 1, 2].map((slot) => {
                const placed = progress.stones.includes(slot);
                return (
                  <button
                    key={slot}
                    className={`stone-slot corner-${slot} ${placed ? "placed" : ""}`}
                    aria-label={`给第${slot + 1}个垫角放石头`}
                    disabled={placed}
                    onClick={() => {
                      dispatch({ type: "STONE", slot });
                      feedback("这一个垫角稳稳的了。", progress.stones.length === 2
                        ? ["ui_stone_placed", "optional_stones_complete"]
                        : "ui_stone_placed");
                    }}
                  >
                    {placed ? (
                      <Prop item="stone" />
                    ) : (
                      <span className="corner-mark">＋</span>
                    )}
                  </button>
                );
              })}
            </>
          ) : (
            <>
              <div className="seat-row">
                {progress.seats.map((friend, slot) => {
                  const label = friend
                    ? `${FRIEND_NAMES[friend]}的座位`
                    : `第${slot + 1}个空座位`;
                  const contents = friend ? (
                    <>
                      <FriendPortrait friend={friend} />
                      <span>{FRIEND_NAMES[friend]}</span>
                    </>
                  ) : (
                    <>
                      <span className="seat-plus">＋</span>
                      <span>放这里</span>
                    </>
                  );
                  if (readOnly)
                    return (
                      <div className="plate filled" key={slot}>
                        {contents}
                      </div>
                    );
                  return (
                    <button
                      key={slot}
                      aria-label={label}
                      aria-pressed={Boolean(friend && selected === friend)}
                      className={`plate ${friend ? "filled" : ""} ${selected === friend && friend ? "selected" : ""}`}
                      disabled={!allSeated && Boolean(friend)}
                      onClick={() => {
                        if (allSeated && !selected && friend) {
                          setSelected(friend);
                          feedback(
                            `给${FRIEND_NAMES[friend]}换个位置，点另一个座位就好。`,
                            `ui_seat_select_${friend}`,
                          );
                          return;
                        }
                        if (activeFriend) {
                          dispatch({
                            type: "SEAT",
                            friend: activeFriend,
                            slot,
                          });
                          feedback(
                            `${FRIEND_NAMES[activeFriend]}的位置摆好了。`,
                            `ui_seat_placed_${activeFriend}`,
                          );
                          setSelected(null);
                        }
                      }}
                    >
                      {contents}
                    </button>
                  );
                })}
              </div>
              <div className="decoration-row">
                {(["flower", "leaf"] as const).map((item) => (
                  <div key={item} className="decoration-space">
                    {progress.decorations.includes(item) && (
                      <Prop item={item} />
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </SceneArt>
      {!stones && !readOnly && (
        <div className="picnic-tools">
          <div className="current-friend">
            {activeFriend ? (
              <>
                <FriendPortrait friend={activeFriend} />
                <div>
                  <small>{selected ? "换一个位置" : "现在轮到"}</small>
                  <strong>{FRIEND_NAMES[activeFriend]}的餐具</strong>
                </div>
              </>
            ) : (
              <div>
                <strong>每位朋友都有位置了</strong>
                <small>点餐具，再点另一个座位，可以交换</small>
              </div>
            )}
          </div>
          <div className="decoration-tools">
            <span>再添一点喜欢的</span>
            <div>
              {(["flower", "leaf"] as const).map((item) => (
                <button
                  key={item}
                  className={
                    progress.decorations.includes(item) ? "active" : ""
                  }
                  aria-pressed={progress.decorations.includes(item)}
                  onClick={() => {
                    dispatch({ type: "DECORATE", item });
                    feedback(
                      progress.decorations.includes(item)
                        ? "先收起这个装饰。"
                        : "小小的装饰，让野餐更特别了。",
                      progress.decorations.includes(item)
                        ? "ui_decoration_removed" : "ui_decoration_added",
                    );
                  }}
                >
                  <Prop item={item} />
                  {item === "flower" ? "一朵纸花" : "一片叶子"}
                  {progress.decorations.includes(item) && <Check size={15} />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
